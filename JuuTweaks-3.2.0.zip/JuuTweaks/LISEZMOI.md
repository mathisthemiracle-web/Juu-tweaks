# Juu Tweaks 3.2.0

Optimisation gaming pour Windows 10 et 11. Chaque modification garde la valeur d'origine de Windows et s'annule en un clic.

## Installer

1. Avant d'extraire le zip : clic droit sur le zip > Propriétés > coche « Débloquer » > OK.
2. Extrais tout le zip (ne lance pas l'exe depuis l'intérieur du zip).
3. Double-clic sur `JuuTweaks.exe`, puis accepte la fenêtre de Windows (droits administrateur).
4. Réponds **Oui** à « Installer Juu Tweaks sur ce PC ? ». L'app est copiée dans ton profil, avec un raccourci sur le Bureau et dans le menu Démarrer, et une entrée dans Applications installées. Tu peux ensuite supprimer le dossier extrait.

Aucune fenêtre de terminal ne s'ouvre. Au premier lancement : visite guidée, puis analyse du PC (10 à 20 secondes).

Pour une nouvelle version : extrais le nouveau zip et lance son `JuuTweaks.exe`. Il propose de remplacer la version installée. Tes réglages et sauvegardes sont gardés.

**Avertissement SmartScreen** (« Windows a protégé votre ordinateur ») : normal, l'exe n'est pas signé. Clique « Informations complémentaires » > « Exécuter quand même ».

Si un antivirus bloque `JuuTweaks.exe` : utilise `Secours - lancer sans exe.bat` (même app, avec une fenêtre de terminal).

## Les pages

- **Tableau de bord** : score, alertes (régressions de FPS, tweaks remis par Windows), historique du score, conseil d'achat, profils en un clic.
- **Pour ton PC** : chaque tweak trié selon ton matériel, tes jeux et tes anticheats (recommandé, optionnel, pas pour toi, inutile).
- **Tweaks** : tous les tweaks normaux. « Pourquoi ? » montre exactement ce qui change (clé, valeur actuelle, nouvelle valeur).
- **Expert** (mode Expert) : tweaks « à prouver » et packs JSON.
- **GPU et BIOS** : réglages du pilote NVIDIA appliqués pour toi (NVIDIA Profile Inspector), HDR par écran, guides BIOS et outils (CRU, NVCleanstall, DDU).
- **Juu Power Plan** : 4 profils (Adaptive, Competitive, Maximum, Balanced Gaming). Adaptive choisit selon ton matériel et le gagnant du tournoi ; sur un Ryzen X3D à deux CCD, il impose le plan Équilibré de Windows (recommandation d'AMD). Règle les P-cores et les E-cores séparément, le parking, la montée en fréquence et des sous-groupes cachés.
- **Session et moteur** : **Prêt à jouer ?** (ping et gigue vers le serveur du jeu, téléchargements en arrière-plan, charge, température, écrans, redémarrage en attente : feu vert, jaune ou rouge), session, mode Tournoi, Juu Balance, Auto-Session par jeu, horaires.
- **Benchmark et preuve** : passes multiples avec intervalle de confiance, courbe des temps d'image (avec dégradé), goulot GPU/CPU, causes des saccades, mode preuve A/B, compteur FPS en direct, image avant / après. Nouveau : coût CPU et GPU par image (PresentMon 2), score de fluidité, latence entrée->image, test séquentiel (s'arrête dès que c'est clair), mode replay (Ctrl+Alt+B), mémoire vidéo, saccades de shaders, prédiction d'upgrade, **Auto-Tuner** (trouve la meilleure config tout seul), **bissection** (trouve le tweak qui fait baisser les FPS), **test à l'aveugle** (le tweak est activé en secret, tu notes ton ressenti) et pré-vol des captures (attend que l'arrière-plan se calme).
- **Jeux** : **bibliothèque** Steam, Epic et Riot (avec le type de disque de chaque jeu et quoi faire s'il est sur un disque dur), raccourcis **« Jouer avec Juu »** sur le Bureau (session + options du jeu, puis tout est remis quand tu fermes le jeu, même si l'app n'est pas ouverte), options par jeu (priorités, QoS, CFG, profil NVIDIA, CPU sets, isolation, résolution étirée, HDR), Fortnite, Valorant, CS2.
- **Labo** (mode Expert) : précision du minuteur, DPC/ISR par cœur (+ cœur conseillé), placement des threads, gigue réseau réelle du jeu (pktmon), trace système (WPR), latence physique réelle (LDAT maison, voir le dossier `extras`), et communauté anonyme (optionnelle).
- **Journal de perfs** : 20 secondes de mesure de temps à autre pendant que tu joues (PresentMon, rien n'est changé), courbe par jeu sur 60 jours, journal des changements du PC (pilote, Windows, BIOS, apps et services au démarrage, tweaks), « ce qui a changé tes FPS », bulletin des pilotes GPU, sauvegarde automatique avant les mises à jour de Windows.
- **Diagnostic** : qui garde ton PC éveillé (veille, minuteurs, périphériques de réveil, minuteur système par app), écrans à la mauvaise fréquence, WHEA, plantages, DPC, bridage, RAM simple canal, PCIe, câble d'écran, BIOS, chipset, SSD, batterie, laptop.
- **Réseau** : assistant routeur (double NAT, CGNAT, UPnP, SQM), surveillance de la route avec rapport pour ton fournisseur, ping, bufferbloat, traceroute vers les serveurs du jeu, DNS chiffré, MTU, cartes virtuelles, limite d'envoi par app, blocage pare-feu.
- **Matériel** (mode Expert) : taux réel de la souris, double frappe du clavier, réaction, pixels morts.
- **Nettoyage** (dont **Installer des apps** : Steam, Epic, Battle.net, EA, Ubisoft, GOG, Brave, Firefox, Chrome, Opera GX, Discord, OBS, MSI Afterburner, HWiNFO... avec winget), **Restauration** (ligne du temps, export .reg, différences, retour à une date), **Partage et IA**, **Mythes**, **Paramètres** (dont **Support et auto-test** : vérifie tout sans rien modifier, et envoie un rapport de bug au salon #support).

Raccourcis : **Ctrl+K** pour tout chercher, **Ctrl+Alt+J** pour afficher Juu Tweaks de n'importe où.

**Mode sans échec** : garde la touche **Maj** enfoncée en lançant Juu Tweaks. Le moteur, les sessions automatiques et les horaires sont coupés, rien n'est appliqué tout seul : tu peux tout annuler ou envoyer un rapport de bug.

## Premier test recommandé

1. Page **Benchmark et preuve** : lance ton jeu, choisis-le, 3 passes, capture « Avant tweaks ». Quand tu cliques, Juu Tweaks se réduit : la capture démarre toute seule dès que le jeu est au premier plan (un son au début, un son à la fin). Pas besoin d'être en plein écran avant de cliquer.
2. Page **Pour ton PC** : applique les recommandés.
3. Redémarre le PC.
4. Refais une capture « Après tweaks » au même endroit. Ou utilise directement le **mode preuve**, qui fait tout ça et te donne un verdict.

## Tout annuler

Page **Restauration** > « Tout annuler », ou « Annuler tout depuis cette date ». L'export .reg garde les valeurs d'origine du registre dans un fichier à double-cliquer. Un point de restauration Windows est créé avant chaque application de tweaks (option dans Paramètres).

La garde de démarrage (Paramètres) annule les tweaks qui demandent un redémarrage si Windows n'arrive pas à ouvrir ta session 3 fois de suite. Elle ne protège pas contre un écran bleu avant le chargement de Windows : pour ça, le point de restauration reste le filet de sécurité.

## Où sont les données

`C:\ProgramData\JuuTweaks\`

- `backup.json` : valeurs d'origine de tout ce que l'app a modifié
- `settings.json` : tes réglages (la clé API est chiffrée avec ton compte Windows)
- `history.json` : ligne du temps
- `logs\` : journal de chaque journée
- `bench\` : résultats, courbes, mode preuve
- `files\` : copies de sauvegarde (fichiers de jeux, profils NVIDIA)
- `packs\` : packs de tweaks importés
- `tools\` : PresentMon et NVIDIA Profile Inspector (téléchargés quand tu en as besoin)
- `bench\diary.json` : journal de perfs ; `changes.json` : journal des changements du PC
- `library.json` : bibliothèque de jeux ; `snapshots\` : sauvegardes avant les mises à jour de Windows
- `crash.log` : seulement si l'app plante (au lancement suivant, Juu Tweaks propose d'envoyer un rapport)

L'app installée est dans `%LOCALAPPDATA%\Programs\JuuTweaks\`.

Pour lancer avec la console visible (débogage) : `JuuTweaks.exe -Console`

## Mises à jour

Deux options dans Paramètres > Mises à jour :

- **GitHub** : mets `compte/projet`. Juu Tweaks lit la dernière release, qui doit contenir un fichier `JuuTweaks.ps1`. La somme de contrôle vient de GitHub (champ digest) ou d'un fichier `JuuTweaks.ps1.sha256` joint à la release.
- **version.json** : modèle dans `version.json.exemple`. L'empreinte se calcule avec `Get-FileHash JuuTweaks.ps1 -Algorithm SHA256`.

## .exe et winget

- **Construire le .exe** (Paramètres) : installe le module ps2exe pour ton compte et crée `JuuTweaks.exe` sur le Bureau. Il n'est pas signé : SmartScreen avertit au premier lancement (Informations complémentaires > Exécuter quand même). Un certificat de signature de code coûte de l'argent et ne peut pas être fourni par l'app.
- **Manifeste winget** : crée les 3 fichiers YAML à partir du zip de ta release. Tu dois publier le zip sur GitHub puis soumettre le dossier à `microsoft/winget-pkgs` toi-même.

## Assistant IA

Paramètres > clé API Anthropic (console.anthropic.com). La clé est chiffrée avec ton compte Windows. Ta config est envoyée à Anthropic seulement quand tu poses une question. Le modèle est modifiable (par défaut `claude-sonnet-5-5`). L'utilisation de l'API est facturée par Anthropic.

## Limites (honnêtement)

- Rien n'a été testé sur un vrai Windows pendant le développement : syntaxe, C#, XAML, traductions et logique ont été vérifiés automatiquement, mais garde un point de restauration et signale tout bug.
- Les tweaks avancés (interruptions sur un cœur dédié, MSI, isolation du jeu) sont marqués EXPERT et passent par la garde de démarrage : si Windows ne démarre plus 3 fois, ils s'annulent tout seuls. Prouve-les avec le mode preuve avant de les garder.
- **Communauté** : tu dois héberger toi-même le petit serveur gratuit (Cloudflare Worker fourni dans `extras/juu-community-worker.js`), puis coller son adresse dans la page Labo. Rien n'est envoyé tant que tu n'actives pas le partage.
- **LDAT maison** : demande un montage Arduino + photodiode (plan dans `extras/JuuLDAT.ino`). Sans l'appareil, la carte de latence physique reste vide.
- **Auto-Tuner et tournoi des plans** : changent des réglages à répétition pendant les mesures puis remettent tout comme avant. Reste dans une scène stable du jeu.
- **Trace WPR** : Juu Tweaks enregistre la trace, mais ne l'analyse pas automatiquement (trop détaillé) : ouvre le fichier dans Windows Performance Analyzer (WPA).
- **Désactiver le MPO** : sur Windows 11 24H2, rien ne confirme que la clé est encore respectée. Vérifie le mode d'affichage réel dans le détail d'une capture.
- **URO** : seulement sur Windows 11 24H2.
- Overclock d'écran, pilote NVIDIA minimal, installation propre du pilote : guides et liens vers les outils de référence (CRU, NVCleanstall, DDU), pas de modification automatique.
- Le compteur FPS en direct ne s'affiche pas par-dessus un jeu en plein écran exclusif (seulement en fenêtré sans bordure).
- La route vers les serveurs du jeu voit seulement les connexions TCP (Windows ne montre pas l'adresse des connexions UDP).
- La limite d'envoi par app limite seulement l'envoi, pas le téléchargement.
- **Rapport de bug** : il faut coller l'adresse d'un webhook Discord (salon #support) dans Paramètres > Support et auto-test. Sans webhook, le rapport s'enregistre sur le Bureau. Le nom de ton compte Windows et le nom du PC sont retirés, et tu vois tout le rapport avant l'envoi.
- **Journal de perfs** : marche seulement quand PresentMon a déjà été téléchargé (une capture dans la page Benchmark suffit) et qu'un jeu connu est au premier plan. « Ce qui a changé tes FPS » montre des coïncidences, pas des preuves : confirme avec le mode preuve.
- **Garder le cache des shaders** : la valeur vient de rapports de joueurs, pas de la documentation de Microsoft (marqué EXPÉRIMENTAL).
- **Analyse de 15 s (powercfg /energy)** : le rapport de Windows suit la langue de Windows ; Juu Tweaks le lit de façon approximative.
- **Test à l'aveugle** : la page Tweaks montre quand même l'état du tweak. Ne la regarde pas pendant le test.
- **Jouer avec Juu** : demande les droits administrateur au lancement (comme l'app). Si le lanceur du jeu (Steam, Epic) relance le jeu, Juu Tweaks attend 20 secondes sans le jeu avant de tout remettre.
- **Tweaks qui coupent le réseau 2 à 5 s** (badge « COUPE LE RÉSEAU ») : ils redémarrent la carte réseau. Juu Tweaks avertit si un jeu roule, ne les change jamais en secret pendant une partie (test à l'aveugle : seulement jeu fermé), attend que tu quittes ta partie dans le mode preuve, et les exclut de la bissection.
- **Retirer les minuteurs forcés** : refusé si BitLocker protège le disque système (Windows pourrait demander la clé de récupération).
- Langues : français et anglais.
