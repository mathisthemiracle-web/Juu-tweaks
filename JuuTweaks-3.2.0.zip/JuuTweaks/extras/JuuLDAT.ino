// Juu Tweaks - LDAT maison (mesure de latence clic -> image)
// Materiel : Arduino Pro Micro (ou Leonardo), une photodiode (ex. BPW34) entre A0 et GND,
//            une resistance de 10 kOhm entre A0 et 5V (montage en pont diviseur).
//            Un bouton poussoir entre la broche 2 et GND (il doit aussi cliquer la souris :
//            branche-le en parallele du clic gauche, ou utilise la souris par-dessus le capteur).
// Principe : quand tu cliques, la carte note l'instant, puis attend que la photodiode
//            voie l'ecran s'eclaircir (le muzzle flash / le changement de scene du jeu).
//            Elle envoie "LAT <ms>" sur le port serie (115200 bauds), lu par Juu Tweaks.
//
// A CALIBRER : SEUIL depend de ton ecran et de l'eclairage de la piece.
//              Place le capteur sur la zone qui s'eclaire au tir, dans un coin sombre.

const int PIN_LIGHT = A0;   // photodiode
const int PIN_CLICK = 2;    // bouton (vers GND), INPUT_PULLUP
int   SEUIL      = 200;     // ecart de luminosite qui declenche (0-1023), a ajuster
const unsigned long TIMEOUT_MS = 500;

void setup() {
  Serial.begin(115200);
  pinMode(PIN_CLICK, INPUT_PULLUP);
  pinMode(PIN_LIGHT, INPUT);
}

void loop() {
  // Attend un clic (front descendant)
  if (digitalRead(PIN_CLICK) == HIGH) return;
  int base = analogRead(PIN_LIGHT);           // luminosite avant le tir
  unsigned long t0 = micros();
  // Attend que l'ecran s'eclaircisse
  while (micros() - t0 < TIMEOUT_MS * 1000UL) {
    int now = analogRead(PIN_LIGHT);
    if (now - base > SEUIL) {
      float ms = (micros() - t0) / 1000.0;
      Serial.print("LAT ");
      Serial.println(ms, 1);
      break;
    }
  }
  // Anti-rebond : attend le relachement du bouton
  while (digitalRead(PIN_CLICK) == LOW) delay(5);
  delay(50);
}
