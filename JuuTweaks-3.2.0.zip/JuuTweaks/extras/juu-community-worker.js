// Juu Tweaks - serveur communautaire minimal (Cloudflare Worker, gratuit)
// Deploie-le sur ton compte Cloudflare (dash.cloudflare.com -> Workers), cree un namespace KV
// nomme JUU_KV et lie-le au Worker sous le nom KV. Mets l'URL du Worker dans Juu Tweaks
// (Parametres -> Communaute). Rien d'identifiant n'est stocke : seulement un profil materiel
// generique (ex. "Ryzen 7 7800X3D | RTX 4070 | 32GB"), un identifiant client aleatoire,
// et par tweak un verdict (gain/loss/none) avec le pourcentage.
//
// Routes :
//   POST /submit  { client, hw, proofs:[{Id,Verdict,FpsPct,LowPct}] }
//   GET  /stats?hw=<profil>  -> { hw, n, tweaks: { <id>: { gain, loss, none, n, avgFps } } }

export default {
  async fetch(req, env) {
    const url = new URL(req.url);
    const cors = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'Content-Type', 'Access-Control-Allow-Methods': 'GET,POST,OPTIONS' };
    if (req.method === 'OPTIONS') return new Response(null, { headers: cors });

    if (url.pathname === '/submit' && req.method === 'POST') {
      let b;
      try { b = await req.json(); } catch { return json({ error: 'bad json' }, 400, cors); }
      if (!b || !b.hw || !Array.isArray(b.proofs)) return json({ error: 'bad body' }, 400, cors);
      const hw = String(b.hw).slice(0, 120);
      const client = String(b.client || 'anon').slice(0, 40).replace(/[^a-z0-9]/gi, '');
      const key = 'agg:' + hw;
      let agg = (await env.KV.get(key, 'json')) || { n: 0, clients: {}, tweaks: {} };
      if (!agg.clients[client]) { agg.clients[client] = 1; agg.n++; }
      for (const p of b.proofs.slice(0, 200)) {
        const id = String(p.Id || '').slice(0, 40);
        if (!id) continue;
        const v = ['gain', 'loss', 'none'].includes(p.Verdict) ? p.Verdict : 'none';
        const t = agg.tweaks[id] || { gain: 0, loss: 0, none: 0, n: 0, sumFps: 0 };
        t[v]++; t.n++;
        const f = Number(p.FpsPct); if (!isNaN(f)) t.sumFps += f;
        agg.tweaks[id] = t;
      }
      await env.KV.put(key, JSON.stringify(agg));
      return json({ ok: true }, 200, cors);
    }

    if (url.pathname === '/stats' && req.method === 'GET') {
      const hw = String(url.searchParams.get('hw') || '').slice(0, 120);
      const agg = (await env.KV.get('agg:' + hw, 'json')) || { n: 0, tweaks: {} };
      const out = { hw, n: agg.n, tweaks: {} };
      for (const [id, t] of Object.entries(agg.tweaks)) {
        out.tweaks[id] = { gain: t.gain, loss: t.loss, none: t.none, n: t.n, avgFps: t.n ? Math.round((t.sumFps / t.n) * 10) / 10 : 0 };
      }
      return json(out, 200, cors);
    }
    return json({ error: 'not found' }, 404, cors);
  }
};

function json(o, status, cors) {
  return new Response(JSON.stringify(o), { status, headers: { 'Content-Type': 'application/json', ...cors } });
}
