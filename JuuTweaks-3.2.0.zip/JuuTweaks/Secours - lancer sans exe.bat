@echo off
title Juu Tweaks
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "%~dp0JuuTweaks.ps1"
